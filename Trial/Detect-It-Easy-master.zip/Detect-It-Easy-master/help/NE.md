###This is a description of the NE class.

* You could use all functions from Binary class but with NE prefix (Binary.compareEP -> NE.compareEP)
* You could use all functions from MSDOS class but with NE prefix (MSDOS.isDosStubPresent -> NE.isDosStubPresent)