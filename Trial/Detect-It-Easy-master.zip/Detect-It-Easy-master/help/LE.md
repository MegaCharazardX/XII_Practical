###This is a description of the LE class.

* You could use all functions from Binary class but with LE prefix (Binary.compareEP -> LE.compareEP)
* You could use all functions from MSDOS class but with LE prefix (MSDOS.isDosStubPresent -> LE.isDosStubPresent)
