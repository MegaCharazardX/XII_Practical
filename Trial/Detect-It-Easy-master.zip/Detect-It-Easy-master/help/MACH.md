###This is a description of the MACH class.

* You could use all functions from Binary class but with MACH prefix (Binary.compareEP -> MACH.compareEP)

**bool isLibraryPresent(QString sLibraryName)**

```
```
**quint32 getNumberOfSections()**

```
```
**quint32 getNumberOfSegments()**

```
```
**qint32 getSectionNumber(QString sSectionName)**

```
```
**QString getGeneralOptions()**

```
```
**quint32 getLibraryCurrentVersion(QString sLibraryName)**

```
```
**quint32 getNumberOfCommands()**

```
```
**quint32 getCommandId(quint32 nNumber)**

```
```