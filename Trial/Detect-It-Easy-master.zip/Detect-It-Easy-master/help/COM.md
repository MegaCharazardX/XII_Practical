###This is a description of the COM class.

* You could use all functions from Binary class but with COM prefix (Binary.compareEP -> COM.compareEP)
