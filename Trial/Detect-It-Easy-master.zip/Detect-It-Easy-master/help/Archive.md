###This is a description of the COM class.

* You could use all functions from Binary class but with Arhive prefix (Binary.compare -> Arhive.compare)

**bool isArchiveRecordPresent(const QString &sArchiveRecord)**

```
```
**bool isArchiveRecordPresentExp(const QString &sArchiveRecord)**

```
```
