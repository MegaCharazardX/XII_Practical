###This is a description of the Util class.

**quint64 shlu64(quint64 nValue, quint64 nShift)**

```
```
**quint64 shru64(quint64 nValue, quint64 nShift)**

```
```
**qint64 shl64(qint64 nValue, qint64 nShift)**

```
```
**qint64 shr64(qint64 nValue, qint64 nShift)**

```
```
**Util.divu64(quint64 nDividend, quint64 nDivisor)**

```
```
**Util.div64(qint64 nDividend, qint64 nDivisor)**

```
```
**QString secondsToTimeStr(qint32 nValue)**

```
```
