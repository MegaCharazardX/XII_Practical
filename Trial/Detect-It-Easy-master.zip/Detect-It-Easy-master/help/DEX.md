###This is a description of the DEX class.

* You could use all functions from Binary class but with DEX prefix (Binary.compare -> DEX.compare)

**bool isStringPoolSorted()**

```
```
**bool isOverlayPresent()**

```
```
**bool isDexStringPresent(QString sString)**

```
```
**bool isDexItemStringPresent(QString sItemString)**

```
```
