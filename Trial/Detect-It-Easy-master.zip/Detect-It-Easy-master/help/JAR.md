###This is a description of the JAR class.

* You could use all functions from Binary class but with JAR prefix (Binary.compare -> JAR.compare)

**QString getManifest()**

```
```
**QString getManifestRecord(const QString &sRecord)**

```
```
