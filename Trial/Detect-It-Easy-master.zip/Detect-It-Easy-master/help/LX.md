###This is a description of the LX class.

* You could use all functions from Binary class but with LX prefix (Binary.compareEP -> LX.compareEP)
* You could use all functions from MSDOS class but with LX prefix (MSDOS.isDosStubPresent -> LX.isDosStubPresent)
