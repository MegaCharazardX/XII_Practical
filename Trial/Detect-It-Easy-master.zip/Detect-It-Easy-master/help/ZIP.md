###This is a description of the ZIP class.

* You could use all functions from Binary class but with ZIP prefix (Binary.compareEP -> ZIP.compareEP)

**bool isArchiveRecordPresent(QString sArchiveRecord)**

```
```

