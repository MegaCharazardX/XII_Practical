4D 5A 90 ?? ?? 00 00 00 04 00 00 00 FF FF 00 00 B8 00 00 00

4D 5A 90 .. .. 00 00 00 04 00 00 00 FF FF 00 00 B8 00 00 00

'MZ'90....00000004000000FFFF0000B8000000

Normal Signatures. '?' or '.' - wildcards


83CDFFEB$$8B1E83EEFC11DB72$$8A0646

"Jump" signatures. $$, $$$$, $$$$$$$$ jump distance


"Address" signatures. ####, ######## address for next instructions


\*\*CDFFEB

\*\* not null


!!CDFFEB

!! not ANSI


\_\_CDFFEB

\_\_ not ANSI and not null


CD+EB

"Delta signatures"