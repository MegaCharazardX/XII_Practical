###This is a description of the APK class.

* You could use all functions from Binary class but with APK prefix (Binary.compare -> APK.compare)

**QString getAndroidManifest()**

```
```
**QString getAndroidManifest(const QString &sRecord)**

```
```
