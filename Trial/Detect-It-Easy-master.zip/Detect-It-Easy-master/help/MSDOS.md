###This is a description of the MSDOS class.

* You could use all functions from Binary class but with MSDOS prefix (Binary.compareEP -> MSDOS.compareEP)

**bool isLE()**

```
```
**bool isLX()**

```
```
**bool isNE()**

```
```
**bool isPE()**

```
```
**qint64 getDosStubOffset()**

```
```
**qint64 getDosStubSize()**

```
```
**bool isDosStubPresent()**

```
```
**bool isRichSignaturePresent()**

```
```
**qint32 getNumberOfRichIDs()**

```
```
**bool isRichVersionPresent(quint32 nVersion)**

```
```
**quint32 getRichVersion(qint32 nPosition)**

```
```
**quint32 getRichID(qint32 nPosition)**

```
```

**quint32 getRichCount(qint32 nPosition)**

```
```